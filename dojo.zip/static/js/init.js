dojo.require("dojo.dom");
dojo.require("dojo.parser");
dojo.require("dijit.registry");
dojo.require("dojo.domReady!");

dojo.require("dijit.dijit");
dojo.require("dojo.html");
dojo.require("app.util.htmlUtil");
dojo.require("app.util.common");
dojo.require("app.security.login");


dojo.addOnLoad(function(){
	//Parsing htmls with dojo components and widgets.
    dojo.parser.parse();
	
	//Bind click action to show login form
    dojo.connect(app.util.htmlUtil.getById(app.util.common.CONS.userInfoNav), "onclick", function(e) {
        app.util.htmlUtil.show(  app.util.common.CONS.loginWrapper );
    });

	//Click function for close button for login form.
    dojo.connect(app.util.htmlUtil.getById(app.util.common.CONS.closeLogin), "onclick", function(e) {
        app.util.htmlUtil.hide(  app.util.common.CONS.loginWrapper );
    });

	//Click function for login form submit
    dojo.connect(app.util.htmlUtil.getById(app.util.common.login.submit), "onclick", function(e) {
        app.security.login.requestLogin();
    });
});
