define("app/mail/mailinit", [
    "dojo/_base/declare",
	"dojo/store/Memory",
	"dijit/tree/ObjectStoreModel", 
	"dijit/Tree",
    "dijit/_WidgetBase",
	"dojo/json",
    "dijit/_OnDijitClickMixin",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/form/Button",
	"app/util/rest",
    "dojo/text!./html/container.html"
], function(declare, Memory, ObjectStoreModel, Tree, _WidgetBase, json, _OnDijitClickMixin, _TemplatedMixin,
            _WidgetsInTemplateMixin, Button,rest, template) {

    return declare([_WidgetBase, _OnDijitClickMixin,
        _TemplatedMixin, _WidgetsInTemplateMixin
    ], {
        templateString: template,
		
		 
		initTree: function() {
			console.log()
		} 
		
    });

});