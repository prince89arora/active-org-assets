define("app/security/login", [
    "dojo/_base/declare",
    "app/util/common",
    "app/util/rest",
    "app/util/htmlUtil",
    "dojo/cookie"
], function(declare, common, rest, htmlUtil, cookie) {

    var login = {

        requestLogin : function() {
           var response = rest.login( htmlUtil.getValue(common.login.usernameId) , htmlUtil.getValue(common.login.passwordId));
           this.loginCallBack(response);            
        },

        loginCallBack: function(response) {
		   if (response.status) {
			   //creating cookie to add login token cane in service response.	
			   cookie("loginid", response.token, { expires: 10 }); 
			   htmlUtil.hide(  common.CONS.loginWrapper );
		   } else {
			   //Showing error in case of invalid login.
			   console.log("error id: "+ common.CONS.loginErrorId)
			   htmlUtil.setHtml( common.CONS.loginErrorId, common.error.invalidLogin ); 
		   }    
		}
	};

    return login;
});
